﻿$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
& (Join-Path $PSScriptRoot 'Verify-Package.ps1')
if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw 'Проверка пакета не прошла.' }
$distribution = Join-Path $script:PackageRoot 'dist'
New-Item -ItemType Directory -Force -Path $distribution | Out-Null
$temporaryRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
$stage = Join-Path $temporaryRoot ('th09-ru-release-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage | Out-Null
try {
    $included = @('runtime', 'translation', 'scripts', 'licenses', 'README.md', 'THIRD_PARTY_NOTICES.md', 'payload-manifest.json', 'translation-sources.json', 'preview.png', 'Install.cmd', 'Play-Russian.cmd', 'Steam-Setup.cmd', 'Verify.cmd', '.gitignore', '.gitattributes')
    foreach ($name in $included) {
        $source = Join-Path $script:PackageRoot $name
        if (!(Test-Path -LiteralPath $source)) { throw ('Не найден файл выпуска: ' + $name) }
        Copy-Item -LiteralPath $source -Destination $stage -Recurse -Force
    }
    $zip = Join-Path $distribution ('Touhou9-Russian-Steam-v' + $script:PackageVersion + '.zip')
    Compress-Archive -LiteralPath @((Get-ChildItem -LiteralPath $stage -Force).FullName) -DestinationPath $zip -Force
    $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText((Join-Path $distribution 'SHA256SUMS.txt'), ($hash + '  ' + [IO.Path]::GetFileName($zip) + "`n"), (New-Object Text.UTF8Encoding($false)))
    Write-Host ('Готово: ' + $zip) -ForegroundColor Green
    Write-Host ('SHA-256: ' + $hash)
} finally {
    $resolved = [IO.Path]::GetFullPath($stage)
    if ($resolved.StartsWith($temporaryRoot, [StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($resolved) -match '^th09-ru-release-[0-9a-f]{32}$') {
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}

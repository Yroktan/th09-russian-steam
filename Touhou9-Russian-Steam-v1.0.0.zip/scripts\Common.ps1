﻿$ErrorActionPreference = 'Stop'
$script:PackageRoot = Split-Path -Parent $PSScriptRoot
$script:PackageVersion = '1.0.0'

function Get-TranslatorCache {
    Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) ('Touhou9-Russian-Steam\' + $script:PackageVersion)
}

function Find-SteamGame {
    $libraries = New-Object 'System.Collections.Generic.List[string]'
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        $value = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($value) {
            foreach ($property in @('SteamPath', 'InstallPath')) {
                if ($value.PSObject.Properties[$property] -and $value.$property) {
                    $libraries.Add([string]$value.$property)
                }
            }
        }
    }
    $defaultSteam = Join-Path ${env:ProgramFiles(x86)} 'Steam'
    if (Test-Path -LiteralPath $defaultSteam) { $libraries.Add($defaultSteam) }
    $roots = @($libraries.ToArray())
    foreach ($steamRoot in $roots) {
        $vdf = Join-Path $steamRoot 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            $text = [IO.File]::ReadAllText($vdf)
            foreach ($match in [regex]::Matches($text, '"path"\s+"([^"]+)"')) {
                $libraries.Add($match.Groups[1].Value.Replace('\\', '\'))
            }
        }
    }
    foreach ($library in @($libraries.ToArray() | Select-Object -Unique)) {
        $manifest = Join-Path $library 'steamapps\appmanifest_1420810.acf'
        if (!(Test-Path -LiteralPath $manifest)) { continue }
        $match = [regex]::Match([IO.File]::ReadAllText($manifest), '"installdir"\s+"([^"]+)"')
        if ($match.Success) {
            $folder = Join-Path (Join-Path $library 'steamapps\common') $match.Groups[1].Value
            if (Test-Path -LiteralPath (Join-Path $folder 'th09.exe')) { return $folder }
        }
    }
    return $null
}

function Resolve-GameFolder([string]$GamePath) {
    if ([string]::IsNullOrWhiteSpace($GamePath)) { $GamePath = Find-SteamGame }
    if ([string]::IsNullOrWhiteSpace($GamePath)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Выберите папку Steam-версии Touhou 9, содержащую th09.exe'
        try {
            if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw 'Выбор папки отменён.' }
            $GamePath = $dialog.SelectedPath
        } finally { $dialog.Dispose() }
    }
    if (Test-Path -LiteralPath $GamePath -PathType Leaf) {
        if ([IO.Path]::GetFileName($GamePath) -ine 'th09.exe') { throw 'Выберите папку игры либо th09.exe.' }
        $GamePath = Split-Path -Parent $GamePath
    }
    $GamePath = [IO.Path]::GetFullPath($GamePath)
    $exe = Join-Path $GamePath 'th09.exe'
    if (!(Test-Path -LiteralPath $exe)) { throw 'В выбранной папке отсутствует th09.exe.' }
    $hash = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
    $supported = @{
        '234195e017548c2114c664a6f5592be64720dad5d445a24602e8fa2e792f97ef' = '1.00a (Steam)'
        '10350095bcf95edb59e03bee9849a2dc8a7714b4927ad5909c569c550fce6822' = '1.50a (официальное обновление)'
    }
    if (!$supported.ContainsKey($hash)) {
        throw 'Эта версия th09.exe не проверена. Восстановите файлы игры через Steam либо выберите оригинальную версию 1.00a/1.50a.'
    }
    [pscustomobject]@{ Directory = $GamePath; Executable = $exe; Version = $supported[$hash]; Sha256 = $hash }
}

function Test-TranslatorPayload {
    $path = Join-Path $script:PackageRoot 'payload-manifest.json'
    if (!(Test-Path -LiteralPath $path)) { throw 'Отсутствует payload-manifest.json. Распакуйте полный пакет русификатора.' }
    $manifest = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    $prefix = [IO.Path]::GetFullPath($script:PackageRoot).TrimEnd('\') + '\'
    foreach ($file in $manifest.files) {
        $target = [IO.Path]::GetFullPath((Join-Path $script:PackageRoot $file.path))
        if (!$target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Недопустимый путь в манифесте.' }
        if (!(Test-Path -LiteralPath $target -PathType Leaf)) { throw ('Отсутствует файл: ' + $file.path) }
        if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ine $file.sha256) {
            throw ('Нарушена целостность файла: ' + $file.path)
        }
    }
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
}

function Install-Translator([string]$GamePath) {
    $game = Resolve-GameFolder $GamePath
    $payloadHash = Test-TranslatorPayload
    $cache = Get-TranslatorCache
    $runtime = Join-Path $cache 'thcrap'
    $statePath = Join-Path $cache 'state.json'
    $state = $null
    if (Test-Path -LiteralPath $statePath) {
        try { $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $state = $null }
    }
    $ready = $state -and $state.payloadHash -eq $payloadHash -and (Test-Path -LiteralPath (Join-Path $runtime 'bin\thcrap_tsa.dll')) -and (Test-Path -LiteralPath (Join-Path $runtime 'repos\thpatch\lang_ru\th09\PT Sans-Narrow.ttf'))
    if (!$ready) {
        New-Item -ItemType Directory -Force -Path $runtime, (Join-Path $runtime 'repos'), (Join-Path $runtime 'config') | Out-Null
        foreach ($item in Get-ChildItem -LiteralPath (Join-Path $script:PackageRoot 'runtime') -Force) {
            Copy-Item -LiteralPath $item.FullName -Destination $runtime -Recurse -Force
        }
        foreach ($repo in @('nmlgc', 'thpatch')) {
            Copy-Item -LiteralPath (Join-Path $script:PackageRoot ('translation\' + $repo)) -Destination (Join-Path $runtime 'repos') -Recurse -Force
        }
    }
    New-Item -ItemType Directory -Force -Path (Join-Path $runtime 'config') | Out-Null
    $patches = @('nmlgc/base_tsa', 'nmlgc/base_tasofro', 'nmlgc/script_latin', 'nmlgc/western_name_order', 'thpatch/lang_en', 'thpatch/lang_ru') | ForEach-Object { @{ archive = ('repos/' + $_ + '/') } }
    $configuration = Join-Path $runtime 'config\ru.js'
    $encoding = New-Object Text.UTF8Encoding($false)
    [IO.File]::WriteAllText($configuration, (@{ patches = @($patches); dat_dump = $false } | ConvertTo-Json -Depth 5), $encoding)
    [IO.File]::WriteAllText((Join-Path $runtime 'config\games.js'), (@{ th09 = $game.Executable.Replace('\', '/') } | ConvertTo-Json), $encoding)
    $loader = Join-Path $runtime 'thcrap_loader.exe'
    $options = '"' + $loader + '" "' + $configuration + '" %command%'
    [IO.File]::WriteAllText((Join-Path $cache 'Steam-Launch-Options.txt'), $options, $encoding)
    [IO.File]::WriteAllText($statePath, (@{ payloadHash = $payloadHash; gamePath = $game.Directory; version = $script:PackageVersion } | ConvertTo-Json), $encoding)
    [pscustomobject]@{ Game = $game; Cache = $cache; Runtime = $runtime; Loader = $loader; Configuration = $configuration; SteamOptions = $options }
}

﻿[CmdletBinding()]
param([string]$GamePath, [switch]$ShowSteamOptions)
$ErrorActionPreference = 'Stop'
try {
    . (Join-Path $PSScriptRoot 'Common.ps1')
    $installation = Install-Translator $GamePath
    Write-Host ('Русификатор подготовлен для Touhou 9 ' + $installation.Game.Version) -ForegroundColor Green
    Write-Host 'Файлы th09.exe и th09.dat остаются оригинальными. Перевод применяется внутри игры при запуске.'
    Write-Host 'Для обычного запуска используйте Play-Russian.cmd.'
    Write-Host 'Для Steam: Свойства игры → Общие → Параметры запуска. Вставьте следующую строку:'
    Write-Output $installation.SteamOptions
    Write-Host ('Строка также сохранена в: ' + (Join-Path $installation.Cache 'Steam-Launch-Options.txt'))
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

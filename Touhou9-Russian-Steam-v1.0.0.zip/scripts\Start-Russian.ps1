﻿[CmdletBinding()]
param([string]$GamePath)
$ErrorActionPreference = 'Stop'
try {
    . (Join-Path $PSScriptRoot 'Common.ps1')
    $installation = Install-Translator $GamePath
    $running = Get-CimInstance Win32_Process -Filter "name='th09.exe'" | Where-Object { $_.ExecutablePath -eq $installation.Game.Executable }
    if ($running) { throw 'Touhou 9 уже запущена. Закройте её перед запуском перевода.' }
    Start-Process -FilePath $installation.Loader -ArgumentList @(('"' + $installation.Configuration + '"'), ('"' + $installation.Game.Executable + '"')) -WorkingDirectory $installation.Runtime | Out-Null
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

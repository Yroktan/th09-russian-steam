﻿$ErrorActionPreference = 'Stop'
try {
    . (Join-Path $PSScriptRoot 'Common.ps1')
    $null = Test-TranslatorPayload
    $bad = Get-ChildItem -LiteralPath $script:PackageRoot -File -Recurse -Force | Where-Object {
        $_.FullName -notmatch '[\\/]\.git[\\/]' -and ($_.Name -match '^(th09\.exe|custom\.exe|replayview\.exe|score\.dat|th09\.cfg|games\.js|steam_autocloud\.vdf)$' -or $_.Extension -in @('.dmp', '.dat', '.log'))
    }
    if ($bad) { throw ('В пакете обнаружены посторонние игровые или личные файлы: ' + (($bad | Select-Object -ExpandProperty Name) -join ', ')) }
    Write-Host 'Целостность русификатора проверена. Файлов самой игры, сохранений и журналов в пакете нет.' -ForegroundColor Green
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

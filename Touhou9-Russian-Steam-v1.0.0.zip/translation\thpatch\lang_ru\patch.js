{
  "dependencies": [
    "nmlgc/base_tsa",
    "nmlgc/base_tasofro",
    "nmlgc/western_name_order",
    "nmlgc/script_latin"
  ],
  "fonts": {
    "Cuprum-Bold.ttf": true,
    "Lytiga Pro Condensed.otf": true,
    "PT Sans-Narrow-Web-Bold.ttf": true,
    "PT Sans-Narrow.ttf": true,
    "th08/MyriadPro-Cond.otf": true,
    "th09/PT Sans-Narrow.ttf": true,
    "th13/Cuprum-Bold.ttf": true,
    "mplus-1c-medium.ttf": true,
    "th06/PT Sans-Narrow-Web-Bold.ttf": true,
    "095/PT Sans-Narrow-Web-Bold.ttf": true,
    "th175/TouhouBiolinum-Regular.ttf": true,
    "th175/THB1-Regular.ttf": true,
    "th175/THB1-Regular.otf": true,
    "th175/data/font/ipam.ttf": true,
    "th175/data/font/KH-Dot-Dougenzaka-12.ttf": true,
    "th175/data/font/KH-Dot-Dougenzaka-16.ttf": true
  },
  "id": "lang_ru",
  "servers": [
    "https://srv.thpatch.net/lang_ru/"
  ],
  "title": "Russian language pack",
  "update": false
}